Your personal configuration will be stored here. Updates will never touch this directory. 
