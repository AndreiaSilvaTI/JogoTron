// init script for scene_1

