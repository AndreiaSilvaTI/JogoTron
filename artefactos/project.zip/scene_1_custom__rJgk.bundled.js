// custom script for scene_1

